# Kumu import files

- Import `elements.csv` and `connections.csv` as separate spreadsheets. The element sheet starts with stable IDs; the connection sheet uses `From` and `To` IDs.
- `kumu.json` uses Kumu's JSON blueprint structure (`elements` / `connections`). Each element also includes `group` and `hierarchy` fields for filtering and visual grouping.
- `numerator` and `denominator` fields make each reported ratio's base explicit.
- The map has 42 elements and 42 connections. It summarizes source-reported aggregates, cases, and findings; it creates no individual-trial nodes.
- Connections are limited to relationships explicitly documented in the campaign report, review, or audit. They do not assert tool execution, database access, or disclosure.
- `source` links to the supporting report; `evidence_level` describes whether a value is a source-reported aggregate or a limited model-response observation.
- In Kumu, import the CSV files as elements and connections separately. For JSON, drop the file onto the canvas or choose Import > Advanced > Import JSON file.

Data checkpoint: `ebcb2904a92f`. The ignored SQLite stores and existing Kumu CSV were not present in the checked-out branch. Counts come from the published branch documents and Issue #6; they were not recalculated from the databases. Individual-record verification and turn-level joins require the local evidence store. The repository says raw tool arguments were not retained, so SQLite alone cannot verify their underlying values or execution results.
